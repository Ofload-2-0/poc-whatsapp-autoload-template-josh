import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const HUBSPOT_TOKEN = process.env.HUBSPOT_TOKEN;
const HUBSPOT_WEBHOOK_URL = process.env.HUBSPOT_WEBHOOK_URL;

// AP1 region requires api-ap1.hubapi.com
const HS_BASE = 'https://api-ap1.hubapi.com';

const hsHeaders = () => ({
	Authorization: `Bearer ${HUBSPOT_TOKEN}`,
	'Content-Type': 'application/json',
});

async function safeJson(res, label) {
	const text = await res.text();
	console.log(`\n  [${label}] HTTP ${res.status} — ${text || '(empty)'}`);
	if (!text) return null;
	try { return JSON.parse(text); }
	catch { throw new Error(`${label} returned non-JSON (HTTP ${res.status}): ${text}`); }
}

// ── Step 1: Find HubSpot contact by phone ─────────────────────────────────────
async function findContact(phone) {
	console.log(`\n1. Searching contact: ${phone}`);
	const res = await fetch(`${HS_BASE}/crm/v3/objects/contacts/search`, {
		method: 'POST',
		headers: hsHeaders(),
		body: JSON.stringify({
			filterGroups: [
				{ filters: [{ propertyName: 'phone', operator: 'EQ', value: phone }] },
				{ filters: [{ propertyName: 'mobilephone', operator: 'EQ', value: phone }] },
			],
			properties: ['phone', 'mobilephone', 'firstname', 'lastname'],
			limit: 1,
		}),
	});
	const data = await safeJson(res, 'Contact search');
	if (!res.ok) throw new Error(`Contact search failed (${res.status}): ${JSON.stringify(data)}`);
	console.log(`   Found: ${data?.total ?? 0}`);
	return data?.results?.[0] || null;
}

// ── Step 2: Update contact properties with load variable values ───────────────
async function updateContactProperties(contactId, variables) {
	console.log(`\n2. Updating contact properties for ${contactId}...`);
	const res = await fetch(`${HS_BASE}/crm/v3/objects/contacts/${contactId}`, {
		method: 'PATCH',
		headers: hsHeaders(),
		body: JSON.stringify({
			properties: {
				load_pickup_location:   variables[0],
				load_pickup_date__time: variables[1],
				load_dropoff_location:  variables[2],
				load_dropoff_date__time: variables[3],
				load_cargo:             variables[4],
				load_truck_type:        variables[5],
				load_handling:          variables[6],
				load_restraints:        variables[7],
				load_dg:                variables[8],
				load_carrier_rate:      variables[9],
			},
		}),
	});
	const data = await safeJson(res, 'Contact update');
	if (!res.ok) throw new Error(`Contact update failed (${res.status}): ${JSON.stringify(data)}`);
	console.log('   Properties updated ✓');
}

// ── Step 3: Fire HubSpot webhook to trigger workflow ──────────────────────────
async function triggerWorkflow(contactId, variables) {
	console.log(`\n3. Triggering HubSpot workflow via webhook for contact ${contactId}...`);

	const payload = {
		objectId: contactId,
		pickup_location:  variables[0],
		pickup_datetime:  variables[1],
		dropoff_location: variables[2],
		dropoff_datetime: variables[3],
		cargo:            variables[4],
		truck_type:       variables[5],
		handling:         variables[6],
		restraints:       variables[7],
		dg:               variables[8],
		carrier_rate:     variables[9],
	};

	console.log('   Payload:', JSON.stringify(payload, null, 2));

	const res = await fetch(HUBSPOT_WEBHOOK_URL, {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify(payload),
	});

	const data = await safeJson(res, 'Webhook trigger');
	if (!res.ok) throw new Error(`Webhook trigger failed (${res.status}): ${JSON.stringify(data)}`);
	console.log('   Workflow triggered ✓');
	return data;
}

// ── Route ─────────────────────────────────────────────────────────────────────
app.post('/api/send-whatsapp', async (req, res) => {
	const { phone, variables } = req.body;

	console.log('\n════════════════════════════════════════');
	console.log('  New WhatsApp Send Request');
	console.log(`  Phone:     ${phone}`);
	console.log(`  Variables: ${JSON.stringify(variables)}`);
	console.log('════════════════════════════════════════');

	if (!phone || !variables || variables.length !== 10) {
		return res.status(400).json({ error: 'phone and 10 variables are required.' });
	}

	try {
		const contact = await findContact(phone);
		if (!contact) {
			return res.status(404).json({
				error: `No HubSpot contact found with phone "${phone}". Ensure the contact exists in HubSpot with this number including country code.`,
			});
		}

		await updateContactProperties(contact.id, variables);
		await triggerWorkflow(contact.id, variables);

		const contactName = [contact.properties?.firstname, contact.properties?.lastname]
			.filter(Boolean).join(' ');

		const portalId = process.env.HUBSPOT_PORTAL_ID || '23384711';
		const hubspotUrl = `https://app-ap1.hubspot.com/contacts/${portalId}/contact/${contact.id}/`;

		console.log('\n✅ Done — HubSpot will send the WhatsApp shortly.');
		res.json({ success: true, contactName, contactId: contact.id, hubspotUrl });
	} catch (err) {
		console.error('\n❌ Error:', err.message);
		res.status(500).json({ error: err.message });
	}
});

app.get('/api/health', (_req, res) => {
	res.json({ status: 'ok', webhook: HUBSPOT_WEBHOOK_URL });
});

// ── Annotation endpoints ──────────────────────────────────────────────────────
import { writeFileSync, readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const __dirname = dirname(fileURLToPath(import.meta.url));

app.post('/api/annotations', (req, res) => {
	const { pins, page } = req.body;
	const payload = { page, pins, savedAt: new Date().toISOString() };
	writeFileSync(join(__dirname, 'annotations.json'), JSON.stringify(payload, null, 2));
	console.log(`\n📌 Annotations saved: ${pins.length} pin(s) from ${page}`);
	res.json({ ok: true });
});

app.get('/api/annotations', (_req, res) => {
	try {
		const data = readFileSync(join(__dirname, 'annotations.json'), 'utf8');
		res.json(JSON.parse(data));
	} catch {
		res.json({ pins: [] });
	}
});

const PORT = 3001;
app.listen(PORT, () => {
	console.log(`\n🚀  Server → http://localhost:${PORT}`);
	console.log(`    Webhook: ${HUBSPOT_WEBHOOK_URL}`);
});
