# ofload-whatsapp-poc — Claude Code Rules

## Tech Stack

- **Framework:** React 18 + TypeScript 5
- **Bundler:** Vite
- **Tests:** Jest 29 + React Testing Library + user-event
- **State:** Recoil (client)
- **HTTP:** Axios
- **UI:** MUI Icons, @offload/sinble component library
- **Styling:** SCSS CSS Modules (`.module.scss`)
- **Validation:** useValidation hook with Zod
- **Docs:** Storybook 8

---

## Project Structure

```
src/App/
├── API/              # API hooks and server calls
├── Components/
│   ├── CORE/         # Primitive UI components (Button, Loader, Card…)
│   ├── FORM/         # Form controls (InputField, Select, TypeAhead…)
│   ├── LAYOUT/       # Structural components (Grid, Table, Tabs…)
│   └── PAGE_LAYOUTS/ # Feature/page-level components
├── Hooks/            # Custom React hooks
├── Pages/            # Route-level page components
├── State/            # Recoil atoms and selectors
├── Styles/           # Global SCSS (variables, mixins, resets)
├── Types/            # TypeScript types and enums
└── Utils/            # Pure utility functions
```

---

## Import Aliases

Always use aliases — never relative paths that cross module boundaries.

| Alias | Resolves to |
|---|---|
| `@components` | `src/App/Components` |
| `@types` | `src/App/Types` |
| `@api` | `src/App/API` |
| `@hooks` | `src/App/Hooks` |
| `@utils` | `src/App/Utils` |
| `@styles` | `src/App/Styles` |
| `@state` | `src/App/State` |
| `@pages` | `src/App/Pages` |
| `@img` | `src/App/img` |

---

## Component Conventions

### File structure
Every component lives in its own folder and always includes:

```
ComponentName/
├── ComponentName.tsx          # Component implementation
├── ComponentName.module.scss  # Scoped styles
├── ComponentName.test.tsx     # Tests
├── ComponentName.stories.tsx  # Storybook stories
└── index.ts                   # Barrel export
```

### Implementation pattern

```tsx
import styles from './ComponentName.module.scss';
import { OtherComponent } from '@components';
import { SomeType } from '@types';

export interface ComponentNameProps {
  value: string;
  onChange: (v: string) => void;
  optional?: boolean;
}

export const ComponentName = (props: ComponentNameProps) => {
  const { value, onChange, optional = false } = props;
  return <div className={styles.container}>…</div>;
}
```

- **Named exports only** — no default exports
- **Props interface** named `${ComponentName}Props`, exported from the component file
- **Destructure props** inside the component body, not in the function signature
- **Do not rely on hoisting** make sure all variables and functions are written before they are called.
- **useEffects should be written last** all useEffect functions must be written last just before the return call.
- **Barrel `index.ts`** re-exports the component (and props type if consumers need it)
- **Do not use props if they default** if a component has a property with a default value, no need to set that property on the component
- Props that extend an existing interface use `extends`:
  ```ts
  export interface TypeAheadProps extends InputFieldProps { … }
  ```
- Spread `...otherProps` for pass-through props rather than explicitly listing every base prop

### Component categories
- **CORE** — design-system primitives used everywhere
- **FORM** — controlled input components; always accept `value`/`onChange`
- **LAYOUT** — structural/container components
- **PAGE_LAYOUTS** — feature-specific, composed from CORE/FORM/LAYOUT; not in coverage

---

## TypeScript Conventions

- Types and enums live in `src/App/Types/` and are imported via `@types`
- **Enums** for all constant sets (e.g. `BUTTON_SIZE`, `INPUT_TYPE`)
- `any` is permitted where genuinely needed — `@typescript-eslint/no-explicit-any` is off
- `@ts-ignore` / `@ts-expect-error` are permitted when necessary
- Avoid redundant type annotations where TypeScript can infer
- Type names must start with a capital T and Interface names must start with a capital I:
  ```ts
  type TMyType = { property: string }
  interface IMyInterface { property: string }
  ```

---

## Styling Conventions

- **CSS Modules** (`.module.scss`) for all component styles — no inline styles except for dynamic values
- **CSS custom properties** for all design tokens:
  - Brand: `var(--brand-primary)`, `var(--brand-primary-light)`
  - Neutrals: `var(--neutral-00)` … `var(--neutral-07)`
  - Text: `var(--txt-body)`, `var(--txt-disabled)`, `var(--txt-error)`
  - Controls: `var(--controls-bg-default)`, `var(--controls-border-default)`
  - Inputs: `var(--input-border-default)`, `var(--input-border-error)`, `var(--input-border-disabled)`
  - Functions: `var(--func-red-default)`, `var(--func-green-default)`
- **SCSS nesting** and `&:hover` / `&:has()` selectors are fine
- Media query mixins from `@styles/media-mixins`
- Class names in `camelCase` matching the module key
- Don't duplicate styles, if a class has the exact same styles reuse this class and rename and update for clarity
- Make sure to use CSS variables from the main stylesheet found in :root

---

## Testing Conventions

### Structure
```ts
describe('[COMPONENT - CATEGORY] - ComponentName', () => {
  it('Should do something when something happens', async () => {
    const mockFn = jest.fn();
    render(<ComponentName prop='value' onClick={mockFn} />);

    const el = screen.getByRole('button');
    await userEvent.click(el);

    expect(mockFn).toHaveBeenCalledTimes(1);
  });
});
```

- Describe label format: `[COMPONENT - CATEGORY] - ComponentName`
- Use `userEvent` for user interactions, `fireEvent` only when `userEvent` won't work
- Use `screen.getBy*` / `screen.queryBy*` / `screen.findBy*` — never store the render result
- Mock external modules at the top of the file with `jest.mock()`
- `jest.fn()` for callbacks, `jest.clearAllMocks()` in `beforeEach` when needed
- `data-testid` attributes use the format `@ofload-whatsapp-poc-ComponentName-Description`

### What is and isn't tested
- Coverage excludes: `*.stories.tsx`, `index.ts`, hooks (`use*.ts`), API files, Pages, PAGE_LAYOUTS
- Tests live alongside their component in the same folder

---

## Storybook Conventions

```tsx
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta<typeof ComponentName> = {
  title: 'Design System/CATEGORY/ComponentName',
  component: ComponentName,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof ComponentName>;

export const Default: Story = {
  name: 'ComponentName (Default)',
  args: { … }
}
```

- Title path: `Design System/CATEGORY/ComponentName`
- One story per significant variant
- Use decorators for layout wrapping and stateful demos

---

## Code Style (ESLint enforced)

- **Indentation:** tabs
- **Quotes:** single
- **Semicolons:** required
- **Equality:** always `===` (no `==`)
- **Variables:** `const`/`let` only — no `var`
- **Functions:** arrow function expressions (`const fn = () => {}`)
- **`no-eval`:** error
- `react-hooks/exhaustive-deps` is **off** — do not add exhaustive dep arrays mechanically

---

## Key Patterns to Follow

- **Never** restructure or rename existing exports without checking all consumers
- **Never** add explicit props to a component that already covers them via `extends` + `...otherProps` spread
- **Never** install packages that are not already included in the package.json unless explicitly told to
- **Never** use the MUI library except for Icons
- **Always** Before writing logic in a component, check if it already exists or has a close variant in a utility or a hook and use this
- **Always** Search for and use existing components, types, API services etc before creating new ones
- **Always** use @Offload/sinble library before creating new components
- **Always** Check if arbitrary HTML tags exist as a @offload/sinble component, eg <button> exists as the <Button> component, <p> exists as the <Text> component
- Don't duplicate styles, if a class has the exact same styles reuse this class and rename and update for clarity
- Each utility file should only contain the function(s) for which the file is named for
- When a component wraps another (e.g. TypeAhead wraps TextInput), pass unknown props through `...otherProps` to the underlying component rather than enumerating them
- Prefer editing existing files over creating new ones
- Add Storybook stories and tests for any new component or significant new behaviour
- Run `npx jest --testPathPattern="ComponentName.test" --no-coverage` to verify tests after changes
