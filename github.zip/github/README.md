# ofload-whatsapp-poc

A customer-facing portal built with React 18, TypeScript, and the Ofload Sinble component library.

## Getting started

```bash
npm install
npm run dev
```

## Available scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start the development server |
| `npm run build` | Build for production |
| `npm run preview` | Preview the production build |
| `npm run lint` | Run ESLint |
| `npm run format` | Format source files with Prettier |
