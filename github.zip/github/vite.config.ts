import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
	plugins: [react()],
	resolve: {
		alias: {
			'@components': path.resolve(__dirname, './src/App/Components'),
			'@types':      path.resolve(__dirname, './src/App/Types'),
			'@api':        path.resolve(__dirname, './src/App/API'),
			'@hooks':      path.resolve(__dirname, './src/App/Hooks'),
			'@utils':      path.resolve(__dirname, './src/App/Utils'),
			'@styles':     path.resolve(__dirname, './src/App/Styles'),
			'@state':      path.resolve(__dirname, './src/App/State'),
			'@pages':      path.resolve(__dirname, './src/App/Pages'),
			'@img':        path.resolve(__dirname, './src/App/img'),
		},
	},
	server: {
		open: true,
		proxy: {
			'/api': {
				target: 'http://localhost:3001',
				changeOrigin: true,
			},
		},
	},
	css: {
		preprocessorOptions: {
			sass: {
				api: 'modern-compiler',
				silenceDeprecations: ['legacy-js-api'],
			},
			scss: {
				api: 'modern-compiler',
				silenceDeprecations: ['legacy-js-api'],
			},
		},
	},
});
