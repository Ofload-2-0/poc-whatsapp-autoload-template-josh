import { useState } from 'react';
import { Tile, H1, H2, Text, Spacer } from '@offload/sinble';
import { DUMMY_LOADS } from '../../Data/loads';
import styles from './SendLoadPage.module.scss';

interface TFieldDef {
	key: string;
	label: string;
	placeholder: string;
}

const FIELDS: TFieldDef[] = [
	{ key: '1', label: 'Pick-up location', placeholder: 'e.g. Eagle Farm 4009 QLD' },
	{ key: '2', label: 'Pick-up date & window', placeholder: 'e.g. Fri 14 Feb 2026 • 09:00-17:00' },
	{ key: '3', label: 'Drop-off location', placeholder: 'e.g. Arndell Park 2148 NSW' },
	{ key: '4', label: 'Drop-off date & window', placeholder: 'e.g. Mon 17 Feb 2026 • 09:00-17:00' },
	{ key: '5', label: 'Cargo', placeholder: 'e.g. Ambient • 24 pallets • 10,000 kg' },
	{ key: '6', label: 'Truck type', placeholder: 'e.g. B-Double High Cube Tautliner' },
	{ key: '7', label: 'Handling', placeholder: 'e.g. Pallet jack required' },
	{ key: '8', label: 'Restraints', placeholder: 'e.g. Tension belts | Anti slip mat' },
	{ key: '9', label: 'DG (Dangerous Goods)', placeholder: 'Yes or No' },
	{ key: '10', label: 'Total Carrier Rate', placeholder: 'e.g. $740.34 (Excl. GST)' },
];

type TStatus = 'idle' | 'sending' | 'success' | 'error';

interface ISuccessData {
	conversationId: string;
	messageId: string;
	contactName: string;
}

const emptyVars = () =>
	FIELDS.reduce<Record<string, string>>((acc, f) => ({ ...acc, [f.key]: '' }), {});

export const SendLoadPage = () => {
	const [phone, setPhone] = useState('');
	const [vars, setVars] = useState<Record<string, string>>(emptyVars());
	const [status, setStatus] = useState<TStatus>('idle');
	const [errorMsg, setErrorMsg] = useState('');
	const [successData, setSuccessData] = useState<ISuccessData | null>(null);

	const handleVarChange = (key: string, value: string) => {
		setVars(prev => ({ ...prev, [key]: value }));
	};

	const handleSend = async () => {
		if (!phone.trim()) {
			setErrorMsg('Please enter a recipient phone number.');
			setStatus('error');
			return;
		}

		setStatus('sending');
		setErrorMsg('');

		try {
			const res = await fetch('/api/send-whatsapp', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					phone: phone.trim(),
					variables: FIELDS.map(f => vars[f.key]),
				}),
			});

			const data = await res.json();
			if (!res.ok) throw new Error(data.error || 'Failed to send message');

			setSuccessData(data);
			setStatus('success');
		} catch (err: any) {
			setErrorMsg(err.message);
			setStatus('error');
		}
	};

	const handleReset = () => {
		setStatus('idle');
		setPhone('');
		setVars(emptyVars());
		setSuccessData(null);
		setErrorMsg('');
	};

	const v = (key: string) => vars[key];
	const filled = (key: string) => !!vars[key].trim();

	if (status === 'success') {
		return (
			<div className={styles.page}>
				<div className={styles.successWrap}>
					<Tile>
						<div className={styles.successContent}>
							<span className={styles.successIcon}>✅</span>
							<H1>Message Sent!</H1>
							<Spacer size={8} />
							<Text>WhatsApp sent to <strong>{phone}</strong></Text>
							{successData?.contactName && (
								<Text>Contact: <strong>{successData.contactName}</strong></Text>
							)}
							<Spacer size={6} />
							<Text>It will appear in the HubSpot conversation timeline shortly.</Text>
							<Spacer size={24} />
							<button className={styles.resetBtn} onClick={handleReset}>
								Send Another
							</button>
						</div>
					</Tile>
				</div>
			</div>
		);
	}

	const handleLoadSelect = (id: string) => {
		const record = DUMMY_LOADS.find(l => l.id === id);
		if (!record) return;
		setVars(
			FIELDS.reduce<Record<string, string>>(
				(acc, f, i) => ({ ...acc, [f.key]: record.variables[i] }),
				{}
			)
		);
		setStatus('idle');
		setErrorMsg('');
	};

	return (
		<div className={styles.page}>
			<div className={styles.pageHeader}>
				<H1>Send Load Assignment</H1>
				<Spacer size={4} />
				<Text>Fill in the template and send a WhatsApp notification via HubSpot</Text>
			</div>

			{/* ── Dataset selector ───────────────────────────────────────── */}
			<div className={styles.datasetBar}>
				<label className={styles.datasetLabel}>Load from dataset</label>
				<select
					className={styles.datasetSelect}
					defaultValue=""
					onChange={e => handleLoadSelect(e.target.value)}
				>
					<option value="" disabled>Select a load record…</option>
					{DUMMY_LOADS.map(l => (
						<option key={l.id} value={l.id}>{l.label}</option>
					))}
				</select>
				<span className={styles.datasetHint}>Auto-fills all fields below</span>
			</div>

			<div className={styles.layout}>
				{/* ── Form panel ─────────────────────────────────────────── */}
				<div className={styles.formPanel}>
					<Tile>
						<H2>Recipient</H2>
						<Spacer size={12} />
						<div className={styles.field}>
							<label className={styles.label}>WhatsApp Phone Number</label>
							<input
								className={styles.input}
								type='tel'
								placeholder='+61412345678'
								value={phone}
								onChange={e => setPhone(e.target.value)}
							/>
							<span className={styles.hint}>Must match the phone number on the HubSpot contact. Include country code.</span>
						</div>

						<Spacer size={20} />
						<H2>Load Details</H2>
						<Spacer size={12} />

						{FIELDS.map(field => (
							<div key={field.key} className={styles.field}>
								<label className={styles.label}>
									<span className={styles.varBadge}>{`{{${field.key}}}`}</span>
									{field.label}
								</label>
								<input
									className={styles.input}
									type='text'
									placeholder={field.placeholder}
									value={vars[field.key]}
									onChange={e => handleVarChange(field.key, e.target.value)}
								/>
							</div>
						))}

						<Spacer size={20} />

						{status === 'error' && (
							<>
								<div className={styles.errorBox}>
									<Text>❌ {errorMsg}</Text>
								</div>
								<Spacer size={12} />
							</>
						)}

						<button
							className={styles.sendBtn}
							onClick={handleSend}
							disabled={status === 'sending'}
						>
							{status === 'sending' ? '⏳ Sending...' : '📱 Send via WhatsApp'}
						</button>
					</Tile>
				</div>

				{/* ── Preview panel ──────────────────────────────────────── */}
				<div className={styles.previewPanel}>
					<Tile>
						<H2>Message Preview</H2>
						<Spacer size={4} />
						<Text>Updates live as you type</Text>
						<Spacer size={16} />

						<div className={styles.phoneFrame}>
							<div className={styles.chatHeader}>
								<div className={styles.chatAvatar}>O</div>
								<div>
									<div className={styles.chatName}>Ofload</div>
									<div className={styles.chatStatus}>WhatsApp Business</div>
								</div>
							</div>
							<div className={styles.chatBody}>
								<div className={styles.bubble}>
									<p className={styles.bubbleText}>
										A new load has been allocated to you. Please review the details below and confirm your availability:
									</p>
									<p className={styles.bubbleText}>
										📍 <strong>Pick-up:</strong><br />
										<span className={filled('1') ? styles.filledVal : styles.emptyVal}>{v('1') || '{{1}} Pick-up location'}</span><br />
										<span className={filled('2') ? styles.filledVal : styles.emptyVal}>{v('2') || '{{2}} Pick-up date & time'}</span>
									</p>
									<p className={styles.bubbleText}>
										📍 <strong>Drop-off:</strong><br />
										<span className={filled('3') ? styles.filledVal : styles.emptyVal}>{v('3') || '{{3}} Drop-off location'}</span><br />
										<span className={filled('4') ? styles.filledVal : styles.emptyVal}>{v('4') || '{{4}} Drop-off date & time'}</span>
									</p>
									<p className={styles.bubbleText}>
										<strong>Cargo:</strong> <span className={filled('5') ? styles.filledVal : styles.emptyVal}>{v('5') || '{{5}}'}</span><br />
										<strong>Truck type:</strong> <span className={filled('6') ? styles.filledVal : styles.emptyVal}>{v('6') || '{{6}}'}</span><br />
										<strong>Handling:</strong> <span className={filled('7') ? styles.filledVal : styles.emptyVal}>{v('7') || '{{7}}'}</span><br />
										<strong>Restraints:</strong> <span className={filled('8') ? styles.filledVal : styles.emptyVal}>{v('8') || '{{8}}'}</span><br />
										<strong>DG:</strong> <span className={filled('9') ? styles.filledVal : styles.emptyVal}>{v('9') || '{{9}}'}</span>
									</p>
									<p className={styles.bubbleText}>
										<strong>Total Carrier Rate:</strong><br />
										<span className={filled('10') ? styles.filledVal : styles.emptyVal}>{v('10') || '{{10}}'}</span>
									</p>
									<p className={styles.bubbleDisclaimer}>
										<em>Important: By clicking &apos;Accept Load&apos; below, you confirm you have the capacity to complete this job safely and agree to the CoR obligations and Ofload Terms &amp; Conditions.</em>
									</p>
									<div className={styles.bubbleTime}>
										{new Date().toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit' })} ✓✓
									</div>
								</div>
							</div>
						</div>
					</Tile>
				</div>
			</div>
		</div>
	);
};

export default SendLoadPage;
