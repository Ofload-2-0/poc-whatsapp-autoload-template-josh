import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { DUMMY_LOADS, DUMMY_CARRIERS, ICarrier } from '../../Data/eos';
import styles from './AllocateCarrierPage.module.scss';

type TSendStatus = 'idle' | 'sending' | 'success' | 'error';

const RatingBadge = ({ rating }: { rating: number | null }) => {
	if (rating === null) return <span className={styles.ratingEmpty}>—</span>;
	const cls = rating >= 60 ? styles.ratingGood : rating >= 30 ? styles.ratingMid : styles.ratingBad;
	return <span className={`${styles.rating} ${cls}`}>{rating}</span>;
};

const WaIcon = () => (
	<svg width='13' height='13' viewBox='0 0 24 24' fill='currentColor'>
		<path d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z'/>
	</svg>
);

export const AllocateCarrierPage = () => {
	const { id } = useParams<{ id: string }>();
	const navigate = useNavigate();
	const load = DUMMY_LOADS.find(l => l.id === id);

	const [sendStatus, setSendStatus] = useState<Record<string, TSendStatus>>({});
	const [errorMsg, setErrorMsg] = useState<Record<string, string>>({});
	const [phoneOverride, setPhoneOverride] = useState<Record<string, string>>({});
	const [showPhoneInput, setShowPhoneInput] = useState<Record<string, boolean>>({});
	const [allocated, setAllocated] = useState<Record<string, boolean>>({});

	if (!load) return <div className={styles.notFound}>Load not found.</div>;

	const handleShowWhatsApp = (carrier: ICarrier) => {
		setShowPhoneInput(prev => ({ ...prev, [carrier.id]: true }));
		if (!phoneOverride[carrier.id]) {
			setPhoneOverride(prev => ({ ...prev, [carrier.id]: carrier.contactPhone }));
		}
	};

	const handleAllocate = (carrier: ICarrier) => {
		setAllocated(prev => ({ ...prev, [carrier.id]: true }));
	};

	const handleSendWhatsApp = async (carrier: ICarrier) => {
		const phone = phoneOverride[carrier.id] || carrier.contactPhone;
		setSendStatus(prev => ({ ...prev, [carrier.id]: 'sending' }));
		setErrorMsg(prev => ({ ...prev, [carrier.id]: '' }));

		try {
			const res = await fetch('/api/send-whatsapp', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					phone,
					variables: [
						load.firstStop.name + ', ' + load.firstStop.suburb + ' ' + load.firstStop.postcode + ' ' + load.firstStop.state,
						load.firstStop.date,
						load.lastStop.name + ', ' + load.lastStop.suburb + ' ' + load.lastStop.postcode + ' ' + load.lastStop.state,
						load.lastStop.date,
						load.cargo,
						load.truckType,
						load.palletHandling || 'N/A',
						load.loadRestraints || 'N/A',
						load.dg ? 'Yes' : 'No',
						`$${(load.transportPrice + load.fuelLevy).toFixed(2)} (Excl. GST)`,
					],
				}),
			});

			const data = await res.json();
			if (!res.ok) throw new Error(data.error || 'Send failed');
			setSendStatus(prev => ({ ...prev, [carrier.id]: 'success' }));
		} catch (err: any) {
			setSendStatus(prev => ({ ...prev, [carrier.id]: 'error' }));
			setErrorMsg(prev => ({ ...prev, [carrier.id]: err.message }));
		}
	};

	return (
		<div className={styles.page}>
			<div className={styles.pageHeader}>
				<h1 className={styles.title}>Allocate Carrier</h1>
				<button className={styles.historyBtn}>
					<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
						<circle cx='12' cy='12' r='10'/><polyline points='12 6 12 12 16 14'/>
					</svg>
					View bid history
				</button>
			</div>

			<div className={styles.card}>
				<div className={styles.cardToolbar}>
					<div />
					<div className={styles.cardActions}>
						<button className={styles.actionBtn}>
							<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><line x1='4' y1='6' x2='20' y2='6'/><line x1='4' y1='12' x2='20' y2='12'/><line x1='4' y1='18' x2='20' y2='18'/></svg>
							Display Settings
						</button>
						<div className={styles.searchBox}>
							<input className={styles.searchInput} placeholder='Search' />
							<svg className={styles.searchIcon} width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/></svg>
						</div>
					</div>
				</div>

				<table className={styles.table}>
					<thead>
						<tr>
							<th className={styles.th}>Carrier</th>
							<th className={styles.th}>Rate Card Cost+</th>
							<th className={styles.th}>Rating</th>
							<th className={styles.th}>Carrier Stats</th>
							<th className={styles.th}>Similar Shipments</th>
							<th className={styles.th}>Total Shipments</th>
							<th className={styles.th} />
						</tr>
					</thead>
					<tbody>
						{DUMMY_CARRIERS.map(carrier => {
							const status = sendStatus[carrier.id] || 'idle';
							const showing = showPhoneInput[carrier.id];
							const isAllocated = allocated[carrier.id];

							return (
								<tr key={carrier.id} className={styles.row}>
									<td className={styles.td}>
										<div className={styles.carrierName}>{carrier.name}</div>
										<div className={styles.carrierContact}>{carrier.contactName}: {carrier.contactPhone}</div>
									</td>
									<td className={styles.td}>{carrier.rateCardCost}</td>
									<td className={styles.td}><RatingBadge rating={carrier.rating} /></td>
									<td className={styles.td}>
										<div className={styles.statsIcons}>
											<span className={styles.statIcon} title='App'>📱</span>
											<span className={`${styles.statDot} ${carrier.hasWhatsApp ? styles.statDotActive : ''}`} title='WhatsApp' />
										</div>
									</td>
									<td className={styles.td}>{carrier.similarShipments}</td>
									<td className={styles.td}>{carrier.totalShipments}</td>
									<td className={styles.tdAction}>
										<div className={styles.actionGroup}>

											{/* WhatsApp send */}
											{status === 'success' ? (
												<span className={styles.sentBadge}>✅ Sent</span>
											) : showing ? (
												<div className={styles.phoneRow}>
													<input
														className={styles.phoneInput}
														value={phoneOverride[carrier.id] || ''}
														onChange={e => setPhoneOverride(prev => ({ ...prev, [carrier.id]: e.target.value }))}
														placeholder='+61412345678'
													/>
													<button
														className={styles.sendBtn}
														onClick={() => handleSendWhatsApp(carrier)}
														disabled={status === 'sending'}
													>
														{status === 'sending' ? '⏳' : 'Send'}
													</button>
													{status === 'error' && (
														<div className={styles.errorMsg}>{errorMsg[carrier.id]}</div>
													)}
												</div>
											) : (
												<button
													className={styles.whatsappBtn}
													onClick={() => handleShowWhatsApp(carrier)}
												>
													<WaIcon />
													Send WhatsApp
												</button>
											)}

											{/* Allocate */}
											{isAllocated ? (
												<span className={styles.allocatedBadge}>✓ Allocated</span>
											) : (
												<button
													className={styles.allocateBtn}
													onClick={() => handleAllocate(carrier)}
												>
													Allocate
												</button>
											)}

										</div>
									</td>
								</tr>
							);
						})}
					</tbody>
				</table>

				<div className={styles.searchCarrier}>
					<div className={styles.searchCarrierLabel}>Search a carrier</div>
					<div className={styles.searchCarrierBox}>
						<input className={styles.searchCarrierInput} placeholder='Search' />
						<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/></svg>
					</div>
				</div>
			</div>

			<div className={styles.footer}>
				<button className={styles.cancelBtn}>Cancel Shipment</button>
				<button className={styles.marketplaceBtn} disabled>Send to Marketplace</button>
			</div>
		</div>
	);
};
