import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { DUMMY_LOADS, DUMMY_CARRIERS, ICarrier } from '../../Data/eos';
import styles from './LoadDetailPage.module.scss';

type TSendStatus = 'idle' | 'sending' | 'success' | 'error';
type TCarrierResponse = 'accepted' | 'declined';

// Logged-in user — in a real app this would come from an auth context
const CURRENT_USER = 'Josh Lemura';
const HS_PORTAL_ID = '23384711';

interface ISentRecord {
	carrierId: string;
	sentBy: string;
	sentAt: string;        // ISO timestamp
	contactId?: string;
	hubspotUrl?: string;
}

// ── localStorage helpers ──────────────────────────────────────────────────────

function lsGetSent(loadId: string): Map<string, ISentRecord> {
	try {
		const raw = localStorage.getItem(`wa_sent_${loadId}`);
		if (!raw) return new Map();
		const arr = JSON.parse(raw) as ISentRecord[];
		return new Map(arr.map(r => [r.carrierId, r]));
	} catch { return new Map(); }
}

function lsSetSent(loadId: string, map: Map<string, ISentRecord>) {
	localStorage.setItem(`wa_sent_${loadId}`, JSON.stringify([...map.values()]));
}

function formatRelativeTime(isoStr: string): string {
	const diff = Date.now() - new Date(isoStr).getTime();
	const mins = Math.floor(diff / 60000);
	if (mins < 1) return 'just now';
	if (mins < 60) return `${mins}m ago`;
	const hrs = Math.floor(mins / 60);
	if (hrs < 24) return `${hrs}h ago`;
	return `${Math.floor(hrs / 24)}d ago`;
}

function lsGetAllocated(loadId: string): string | null {
	return localStorage.getItem(`allocated_${loadId}`);
}

function lsSetAllocated(loadId: string, carrierId: string | null) {
	if (carrierId) localStorage.setItem(`allocated_${loadId}`, carrierId);
	else localStorage.removeItem(`allocated_${loadId}`);
}

function lsGetResponses(loadId: string): Map<string, TCarrierResponse> {
	try {
		const raw = localStorage.getItem(`wa_response_${loadId}`);
		if (!raw) return new Map();
		return new Map(Object.entries(JSON.parse(raw) as Record<string, TCarrierResponse>));
	} catch { return new Map(); }
}

function lsSetResponses(loadId: string, map: Map<string, TCarrierResponse>) {
	localStorage.setItem(`wa_response_${loadId}`, JSON.stringify(Object.fromEntries(map)));
}

// ── Sub-components ────────────────────────────────────────────────────────────

// HubSpot orange "sprocket" logomark (simplified)
const HubSpotIcon = () => (
	<svg width='12' height='12' viewBox='0 0 24 24' fill='currentColor'>
		<path d='M18.164 7.93V5.084a2.198 2.198 0 0 0 1.267-1.978V3.06A2.198 2.198 0 0 0 17.235.863h-.047a2.198 2.198 0 0 0-2.196 2.196v.047c0 .88.52 1.641 1.267 1.978V7.93a6.23 6.23 0 0 0-2.962 1.306L5.48 3.073a2.44 2.44 0 0 0 .07-.562 2.45 2.45 0 1 0-2.45 2.45c.46 0 .888-.13 1.25-.354l7.717 6.086a6.234 6.234 0 0 0-.82 3.09c0 1.182.33 2.285.903 3.222l-2.34 2.34a1.92 1.92 0 0 0-.56-.088 1.929 1.929 0 1 0 1.929 1.929c0-.202-.033-.396-.088-.58l2.31-2.31a6.265 6.265 0 0 0 3.806 1.274 6.28 6.28 0 1 0-1.044-12.47zm1.044 9.892a3.714 3.714 0 1 1 0-7.428 3.714 3.714 0 0 1 0 7.428z'/>
	</svg>
);

// ── Message Preview Modal ─────────────────────────────────────────────────────

interface IPreviewModal {
	carrier: ICarrier;
	variables: string[];
	sending: boolean;
	onConfirm: () => void;
	onClose: () => void;
}

const MessagePreviewModal = ({ carrier, variables, sending, onConfirm, onClose }: IPreviewModal) => {
	const [pickup, pickupDate, dropoff, dropoffDate, cargo, truck, handling, restraints, dg, rate] = variables;

	return (
		<div className={styles.modalBackdrop} onClick={onClose}>
			<div className={styles.modalPanel} onClick={e => e.stopPropagation()}>
				<div className={styles.modalHeader}>
					<div>
						<div className={styles.modalTitle}>Message Preview</div>
						<div className={styles.modalSub}>Sending to {carrier.contactName} · {carrier.contactPhone}</div>
					</div>
					<button className={styles.modalClose} onClick={onClose}>✕</button>
				</div>

				{/* WhatsApp-style phone mockup */}
				<div className={styles.phoneShell}>
					<div className={styles.phoneChatBar}>
						<div className={styles.phoneChatAvatar}>O</div>
						<div>
							<div className={styles.phoneChatName}>Ofload</div>
							<div className={styles.phoneChatSub}>via WhatsApp Business</div>
						</div>
					</div>
					<div className={styles.phoneChatBody}>
						<div className={styles.waBubble}>
							<p>Hi {carrier.contactName.split(' ')[0]},</p>
							<p>We have a load available — please review the details below and let us know if you're interested.</p>
							<div className={styles.waDetails}>
								<div className={styles.waRow}><span className={styles.waLabel}>📍 Pick-up</span><span>{pickup}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>🗓 Pick-up date</span><span>{pickupDate}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>📍 Drop-off</span><span>{dropoff}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>🗓 Drop-off date</span><span>{dropoffDate}</span></div>
								<div className={styles.waDivider}/>
								<div className={styles.waRow}><span className={styles.waLabel}>📦 Cargo</span><span>{cargo}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>🚛 Truck</span><span>{truck}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>🔧 Handling</span><span>{handling}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>⚓ Restraints</span><span>{restraints}</span></div>
								<div className={styles.waRow}><span className={styles.waLabel}>⚠️ DG</span><span>{dg}</span></div>
								<div className={styles.waDivider}/>
								<div className={styles.waRow}><span className={styles.waLabel}>💰 Carrier rate</span><span className={styles.waRate}>{rate}</span></div>
							</div>
							<p>Reply <strong>YES</strong> to accept or <strong>NO</strong> to decline.</p>
							<div className={styles.waTime}>just now ✓✓</div>
						</div>
					</div>
				</div>

				<div className={styles.modalFooter}>
					<button className={styles.modalCancelBtn} onClick={onClose} disabled={sending}>Cancel</button>
					<button className={styles.modalSendBtn} onClick={onConfirm} disabled={sending}>
						{sending ? '⏳ Sending…' : <><WaIcon /> Confirm & Send</>}
					</button>
				</div>
			</div>
		</div>
	);
};

const RatingBadge = ({ rating }: { rating: number | null }) => {
	if (rating === null) return <span className={styles.ratingEmpty}>—</span>;
	const cls = rating >= 60 ? styles.ratingGood : rating >= 30 ? styles.ratingMid : styles.ratingBad;
	return <span className={`${styles.rating} ${cls}`}>{rating}</span>;
};

const WaIcon = () => (
	<svg width='13' height='13' viewBox='0 0 24 24' fill='currentColor'>
		<path d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z'/>
	</svg>
);

// ── Main component ────────────────────────────────────────────────────────────

export const LoadDetailPage = () => {
	const { id } = useParams<{ id: string }>();
	const navigate = useNavigate();
	const load = DUMMY_LOADS.find(l => l.id === id);

	// ── [3] Persistent sent state — init from localStorage ───────────────────
	const [sentCarriers, setSentCarriers] = useState<Map<string, ISentRecord>>(
		() => lsGetSent(id ?? '')
	);

	// ── [5] Allocation — single allocated carrier ID, persisted ──────────────
	const [allocatedCarrierId, setAllocatedCarrierId] = useState<string | null>(
		() => lsGetAllocated(id ?? '')
	);

	// ── Ephemeral UI state ────────────────────────────────────────────────────
	const [sendStatus, setSendStatus] = useState<Record<string, TSendStatus>>({});
	const [errorMsg, setErrorMsg] = useState<Record<string, string>>({});
	const [phoneOverride, setPhoneOverride] = useState<Record<string, string>>({});
	const [showPhoneInput, setShowPhoneInput] = useState<Record<string, boolean>>({});

	// ── Response tracking ─────────────────────────────────────────────────────
	const [responses, setResponses] = useState<Map<string, TCarrierResponse>>(
		() => lsGetResponses(id ?? '')
	);

	// ── Preview modal ─────────────────────────────────────────────────────────
	const [previewCarrier, setPreviewCarrier] = useState<ICarrier | null>(null);
	const [previewSending, setPreviewSending] = useState(false);

	// ── Inline phone editing ──────────────────────────────────────────────────
	const [editingPhone, setEditingPhone] = useState<string | null>(null);

	// ── [6] Bulk-select state ─────────────────────────────────────────────────
	const [selectedCarriers, setSelectedCarriers] = useState<Set<string>>(new Set());
	const [bulkStatus, setBulkStatus] = useState<'idle' | 'sending' | 'done'>('idle');

	if (!load) {
		return (
			<div className={styles.page}>
				<div className={styles.notFound}>Load not found.</div>
			</div>
		);
	}

	const totalPrice = load.transportPrice + load.fuelLevy + load.warrantyFee;

	// ── Helpers ───────────────────────────────────────────────────────────────

	const markSent = (carrierId: string, contactId?: string, hubspotUrl?: string) => {
		setSentCarriers(prev => {
			const next = new Map(prev);
			next.set(carrierId, {
				carrierId,
				sentBy: CURRENT_USER,
				sentAt: new Date().toISOString(),
				contactId,
				hubspotUrl,
			});
			lsSetSent(load.id, next);
			return next;
		});
	};

	const handleShowWhatsApp = (carrier: ICarrier) => {
		// Pre-fill phone override, then open preview
		if (!phoneOverride[carrier.id]) {
			setPhoneOverride(prev => ({ ...prev, [carrier.id]: carrier.contactPhone }));
		}
		setPreviewCarrier(carrier);
	};

	const handleSetResponse = (carrierId: string, response: TCarrierResponse) => {
		setResponses(prev => {
			const next = new Map(prev);
			const isToggleOff = next.get(carrierId) === response;
			if (isToggleOff) next.delete(carrierId);
			else next.set(carrierId, response);
			lsSetResponses(load.id, next);
			return next;
		});

		if (response === 'accepted') {
			// Accepting → auto-allocate (same as clicking Allocate)
			const isToggleOff = responses.get(carrierId) === 'accepted';
			if (isToggleOff) {
				handleUnallocate();
			} else {
				handleAllocate(carrierId);
			}
		} else if (response === 'declined') {
			// Declining the currently allocated carrier → unallocate them
			if (allocatedCarrierId === carrierId && responses.get(carrierId) !== 'declined') {
				handleUnallocate();
			}
		}
	};

	// ── [5] Allocate / Unallocate ─────────────────────────────────────────────

	const handleAllocate = (carrierId: string) => {
		setAllocatedCarrierId(carrierId);
		lsSetAllocated(load.id, carrierId);
	};

	const handleUnallocate = () => {
		setAllocatedCarrierId(null);
		lsSetAllocated(load.id, null);
	};

	// ── Send WhatsApp (single) ────────────────────────────────────────────────

	const buildVariables = () => [
		`${load.firstStop.name}, ${load.firstStop.suburb} ${load.firstStop.postcode} ${load.firstStop.state}`,
		load.firstStop.date,
		`${load.lastStop.name}, ${load.lastStop.suburb} ${load.lastStop.postcode} ${load.lastStop.state}`,
		load.lastStop.date,
		load.cargo,
		load.truckType,
		load.palletHandling || 'N/A',
		load.loadRestraints || 'N/A',
		load.dg ? 'Yes' : 'No',
		`$${(load.transportPrice + load.fuelLevy).toFixed(2)} (Excl. GST)`,
	];

	const handleConfirmPreview = async () => {
		if (!previewCarrier) return;
		setPreviewSending(true);
		await handleSendWhatsApp(previewCarrier);
		setPreviewSending(false);
		setPreviewCarrier(null);
		// Auto-set response to pending
		setResponses(prev => {
			if (prev.has(previewCarrier.id)) return prev; // don't overwrite existing
			const next = new Map(prev);
			next.set(previewCarrier.id, 'pending');
			lsSetResponses(load.id, next);
			return next;
		});
	};

	const handleSendWhatsApp = async (carrier: ICarrier, overridePhone?: string) => {
		const phone = overridePhone ?? phoneOverride[carrier.id] ?? carrier.contactPhone;
		setSendStatus(prev => ({ ...prev, [carrier.id]: 'sending' }));
		setErrorMsg(prev => ({ ...prev, [carrier.id]: '' }));

		try {
			const res = await fetch('/api/send-whatsapp', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ phone, variables: buildVariables() }),
			});
			const data = await res.json();
			if (!res.ok) throw new Error(data.error || 'Send failed');

			// [3] Persist success with sender info and HubSpot link
			markSent(carrier.id, data.contactId, data.hubspotUrl);
			setSendStatus(prev => ({ ...prev, [carrier.id]: 'success' }));
		} catch (err: any) {
			setSendStatus(prev => ({ ...prev, [carrier.id]: 'error' }));
			setErrorMsg(prev => ({ ...prev, [carrier.id]: err.message }));
		}
	};

	// ── [6] Bulk send ─────────────────────────────────────────────────────────

	const toggleSelect = (carrierId: string) => {
		setSelectedCarriers(prev => {
			const next = new Set(prev);
			if (next.has(carrierId)) next.delete(carrierId);
			else next.add(carrierId);
			return next;
		});
	};

	const toggleSelectAll = () => {
		const selectable = DUMMY_CARRIERS
			.filter(c => !sentCarriers.has(c.id) && (allocatedCarrierId === null || allocatedCarrierId === c.id))
			.map(c => c.id);
		const allSelected = selectable.every(id => selectedCarriers.has(id));
		setSelectedCarriers(allSelected ? new Set() : new Set(selectable));
	};

	const handleBulkSend = async () => {
		setBulkStatus('sending');
		const targets = DUMMY_CARRIERS.filter(c => selectedCarriers.has(c.id));
		for (const carrier of targets) {
			await handleSendWhatsApp(carrier);
		}
		setSelectedCarriers(new Set());
		setBulkStatus('done');
		setTimeout(() => setBulkStatus('idle'), 3000);
	};

	const selectableCount = DUMMY_CARRIERS.filter(
		c => !sentCarriers.has(c.id) && (allocatedCarrierId === null || allocatedCarrierId === c.id)
	).length;
	const allSelectableSelected =
		selectableCount > 0 &&
		DUMMY_CARRIERS
			.filter(c => !sentCarriers.has(c.id) && (allocatedCarrierId === null || allocatedCarrierId === c.id))
			.every(c => selectedCarriers.has(c.id));

	return (
		<div className={styles.page}>
			{/* ── Message Preview Modal ────────────────────────── */}
			{previewCarrier && (
				<MessagePreviewModal
					carrier={previewCarrier}
					variables={buildVariables()}
					sending={previewSending}
					onConfirm={handleConfirmPreview}
					onClose={() => setPreviewCarrier(null)}
				/>
			)}

			{/* ── Breadcrumb ──────────────────────────────────── */}
			<nav className={styles.breadcrumb}>
				<span className={styles.breadcrumbLink} onClick={() => navigate('/')}>Unallocated</span>
				<span className={styles.breadcrumbSep}>»</span>
				<span className={styles.breadcrumbCurrent}>{load.reference}</span>
			</nav>

			{/* ── Shipment detail card ─────────────────────────── */}
			<div className={styles.card}>
				<div className={styles.shipmentHeader}>
					<div>
						<h1 className={styles.shipperName}>{load.shipperName}</h1>
						<div className={styles.modeTag}>
							<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
								<rect x='1' y='3' width='15' height='13' rx='1'/>
								<path d='M16 8h4l3 5v3h-7V8z'/>
								<circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>
							</svg>
							Road Shipment
						</div>
					</div>
				</div>

				{/* Stops */}
				<div className={styles.stops}>
					<div className={styles.stop}>
						<div className={styles.stopLabel}>FIRST STOP</div>
						<div className={styles.stopName}>{load.firstStop.name}</div>
						<div className={styles.stopSuburb}>{load.firstStop.suburb}, {load.firstStop.state} {load.firstStop.postcode}</div>
						<div className={styles.stopDate}>{load.firstStop.date}</div>
					</div>
					<div className={styles.stopArrow}>
						<svg width='32' height='16' viewBox='0 0 32 16' fill='none'>
							<line x1='0' y1='8' x2='28' y2='8' stroke='#ccc' strokeWidth='1.5'/>
							<polyline points='22,2 28,8 22,14' fill='none' stroke='#ccc' strokeWidth='1.5'/>
						</svg>
					</div>
					<div className={styles.stop}>
						<div className={styles.stopLabel}>LAST STOP</div>
						<div className={styles.stopName}>{load.lastStop.name}</div>
						<div className={styles.stopSuburb}>{load.lastStop.suburb}, {load.lastStop.state} {load.lastStop.postcode}</div>
						<div className={styles.stopDate}>{load.lastStop.date}</div>
					</div>
				</div>

				<div className={styles.divider} />

				{/* Info grid */}
				<div className={styles.infoGrid}>
					<div className={styles.infoSection}>
						<h3 className={styles.infoTitle}>Identification Numbers:</h3>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Reference #</div>
								<div className={styles.infoValue}>
									{load.reference}
									<button className={styles.copyBtn} title='Copy'>
										<svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
											<rect x='9' y='9' width='13' height='13' rx='2'/><path d='M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1'/>
										</svg>
									</button>
								</div>
							</div>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Purchase Order #</div>
								<div className={styles.infoValue}>—</div>
							</div>
						</div>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Order #</div>
								<div className={styles.infoValue}>{load.orderNumber}</div>
							</div>
						</div>
					</div>

					<div className={styles.infoSection}>
						<h3 className={styles.infoTitle}>Cargo Information:</h3>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Cargo Type</div>
								<div className={styles.infoValue}>{load.cargoType}</div>
							</div>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Truck Size & Type</div>
								<div className={styles.infoValue}>{load.truckType}</div>
							</div>
						</div>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Total Weight</div>
								<div className={styles.infoValue}>{load.totalWeight}</div>
							</div>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Temperature</div>
								<div className={styles.tempBadge}>{load.temperature}</div>
							</div>
						</div>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Load Restraints</div>
								<div className={styles.infoValue}>{load.loadRestraints}</div>
							</div>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Pallet Handling</div>
								<div className={styles.infoValue}>{load.palletHandling}</div>
							</div>
						</div>
					</div>

					<div className={styles.infoSection}>
						<div className={styles.pricingHeader}>
							<h3 className={styles.infoTitle}>Pricing Information:</h3>
							<button className={styles.updateCargoBtn}>
								<svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
									<path d='M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'/>
									<path d='M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z'/>
								</svg>
								Update Cargo
							</button>
						</div>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Transport Price</div>
								<div className={styles.infoValue}>${load.transportPrice.toFixed(2)}</div>
							</div>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Fuel Levy (1%)</div>
								<div className={styles.infoValue}>${load.fuelLevy.toFixed(2)}</div>
							</div>
						</div>
						<div className={styles.infoRow}>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Total Price</div>
								<div className={styles.totalPrice}>${totalPrice.toFixed(2)}</div>
							</div>
							<div className={styles.infoField}>
								<div className={styles.infoLabel}>Warranty Fee</div>
								<div className={styles.infoValue}>${load.warrantyFee.toFixed(2)}</div>
							</div>
						</div>
					</div>
				</div>

				<div className={styles.divider} />

				{/* Stop detail */}
				<div className={styles.stopDetail}>
					<div className={styles.stopDetailHeader}>
						<span>STOP 1 ({load.reference})</span>
						<button className={styles.viewDocsBtn}>
							<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
								<path d='M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z'/><circle cx='12' cy='12' r='3'/>
							</svg>
							View Cargo Documents
						</button>
					</div>
					<div className={styles.stopDetailName}>{load.firstStop.name}</div>
					<div className={styles.stopDetailAddress}>{load.firstStop.address}, {load.firstStop.suburb} {load.firstStop.state} {load.firstStop.postcode}, Australia</div>
					<div className={styles.stopDetailDate}>{load.firstStop.date}</div>
				</div>
			</div>

			{/* ── Allocate Carrier section ─────────────────────── */}
			<div className={styles.allocateSection}>
				<div className={styles.allocateHeader}>
					<h2 className={styles.allocateTitle}>Allocate Carrier</h2>
					<button className={styles.historyBtn}>
						<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<circle cx='12' cy='12' r='10'/><polyline points='12 6 12 12 16 14'/>
						</svg>
						View bid history
					</button>
				</div>

				<div className={styles.carrierCard}>
					{/* ── [6] Bulk action bar ───────────────────────── */}
					{selectedCarriers.size > 0 && (
						<div className={styles.bulkBar}>
							<span className={styles.bulkCount}>{selectedCarriers.size} carrier{selectedCarriers.size !== 1 ? 's' : ''} selected</span>
							<button
								className={styles.bulkSendBtn}
								onClick={handleBulkSend}
								disabled={bulkStatus === 'sending'}
							>
								{bulkStatus === 'sending' ? (
									'⏳ Sending…'
								) : bulkStatus === 'done' ? (
									'✓ All sent!'
								) : (
									<><WaIcon /> Send WhatsApp to {selectedCarriers.size}</>
								)}
							</button>
							<button className={styles.bulkClearBtn} onClick={() => setSelectedCarriers(new Set())}>
								Clear
							</button>
						</div>
					)}

					<div className={styles.carrierToolbar}>
						<div />
						<div className={styles.carrierActions}>
							<button className={styles.actionBtn}>
								<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><line x1='4' y1='6' x2='20' y2='6'/><line x1='4' y1='12' x2='20' y2='12'/><line x1='4' y1='18' x2='20' y2='18'/></svg>
								Display Settings
							</button>
							<div className={styles.searchBox}>
								<input className={styles.searchInput} placeholder='Search' />
								<svg className={styles.searchIcon} width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/></svg>
							</div>
						</div>
					</div>

					<table className={styles.table}>
						<thead>
							<tr>
								{/* [6] Select-all checkbox */}
								<th className={styles.thCheck}>
									<input
										type='checkbox'
										className={styles.checkbox}
										checked={allSelectableSelected}
										onChange={toggleSelectAll}
										title='Select all'
									/>
								</th>
								<th className={styles.th}>Carrier</th>
								<th className={styles.th}>Rate Card Cost+</th>
								<th className={styles.th}>Rating</th>
								<th className={styles.th}>Carrier Stats</th>
								<th className={styles.th}>Similar Shipments</th>
								<th className={styles.th}>Total Shipments</th>
								<th className={styles.th} />
							</tr>
						</thead>
						<tbody>
							{DUMMY_CARRIERS.map(carrier => {
								const status = sendStatus[carrier.id] || 'idle';
								const sentRecord = sentCarriers.get(carrier.id); // [3] persistent
								const wasSent = !!sentRecord;
								const showing = showPhoneInput[carrier.id];

								// [5] Locking logic
								const isAllocated = allocatedCarrierId === carrier.id;
								const isLocked = allocatedCarrierId !== null && !isAllocated;
								const isDeclined = responses.get(carrier.id) === 'declined';

								// Effectively disabled if locked or declined
								const isGreyedOut = isLocked || isDeclined;

								// [6] Selectable = not already sent, not greyed out
								const isSelectable = !wasSent && !isGreyedOut;
								const isSelected = selectedCarriers.has(carrier.id);

								return (
									<tr
										key={carrier.id}
										className={`${styles.carrierRow} ${isGreyedOut ? styles.carrierRowLocked : ''} ${isAllocated ? styles.carrierRowAllocated : ''} ${isDeclined ? styles.carrierRowDeclined : ''}`}
									>
										{/* [6] Row checkbox */}
										<td className={styles.tdCheck}>
											{isSelectable && (
												<input
													type='checkbox'
													className={styles.checkbox}
													checked={isSelected}
													onChange={() => toggleSelect(carrier.id)}
												/>
											)}
										</td>

										<td className={styles.td}>
											<div className={styles.carrierName}>{carrier.name}</div>
											{editingPhone === carrier.id ? (
												<div className={styles.phoneEditRow}>
													<input
														className={styles.phoneEditInput}
														value={phoneOverride[carrier.id] ?? carrier.contactPhone}
														onChange={e => setPhoneOverride(prev => ({ ...prev, [carrier.id]: e.target.value }))}
														onKeyDown={e => { if (e.key === 'Enter' || e.key === 'Escape') setEditingPhone(null); }}
														autoFocus
													/>
													<button className={styles.phoneEditSave} onClick={() => setEditingPhone(null)}>✓</button>
												</div>
											) : (
												<div className={styles.carrierContact}>
													{carrier.contactName}: {phoneOverride[carrier.id] ?? carrier.contactPhone}
													<button
														className={styles.phoneEditBtn}
														onClick={() => {
															if (!phoneOverride[carrier.id]) setPhoneOverride(prev => ({ ...prev, [carrier.id]: carrier.contactPhone }));
															setEditingPhone(carrier.id);
														}}
														title='Edit phone'
													>
														<svg width='11' height='11' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.5'>
															<path d='M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'/>
															<path d='M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z'/>
														</svg>
													</button>
												</div>
											)}
										</td>
										<td className={styles.td}>{carrier.rateCardCost}</td>
										<td className={styles.td}><RatingBadge rating={carrier.rating} /></td>
										<td className={styles.td}>
											<div className={styles.statsIcons}>
												<span className={styles.statIcon}>📱</span>
												<span className={`${styles.statDot} ${carrier.hasWhatsApp ? styles.statDotActive : ''}`} />
											</div>
										</td>
										<td className={styles.td}>{carrier.similarShipments}</td>
										<td className={styles.td}>{carrier.totalShipments}</td>
										<td className={styles.tdAction}>
											<div className={styles.actionGroup}>
												{/* ── WhatsApp cell ───────────────────── */}
												{wasSent && sentRecord ? (
													// [3] Persistent sent badge + response tracking
													<div className={styles.sentInfo}>
														<span className={styles.sentBadge}>✅ Sent</span>
														<span className={styles.sentMeta}>
															{sentRecord.sentBy} · {formatRelativeTime(sentRecord.sentAt)}
														</span>
														<div className={styles.responseBtns}>
															{(['accepted', 'declined'] as TCarrierResponse[]).map(r => (
																<button
																	key={r}
																	className={`${styles.responseBtn} ${styles[`responseBtn_${r}`]} ${responses.get(carrier.id) === r ? styles.responseBtnActive : ''}`}
																	onClick={() => handleSetResponse(carrier.id, r)}
																	title={r.charAt(0).toUpperCase() + r.slice(1)}
																>
																	{r === 'accepted' ? '✓' : '✕'}
																</button>
															))}
															{responses.has(carrier.id) && (
																<span className={`${styles.responseLabel} ${styles[`responseLabel_${responses.get(carrier.id)}`]}`}>
																	{responses.get(carrier.id)}
																</span>
															)}
														</div>
													</div>
												) : isGreyedOut || isAllocated ? (
													// [2] & [5] — hide WA button when locked/declined or this row is allocated
													null
												) : showing ? (
													<div className={styles.phoneRow}>
														<input
															className={styles.phoneInput}
															value={phoneOverride[carrier.id] || ''}
															onChange={e => setPhoneOverride(prev => ({ ...prev, [carrier.id]: e.target.value }))}
															placeholder='+61412345678'
														/>
														<button
															className={styles.sendBtn}
															onClick={() => handleSendWhatsApp(carrier)}
															disabled={status === 'sending'}
														>
															{status === 'sending' ? '⏳' : 'Send'}
														</button>
														{status === 'error' && (
															<div className={styles.errorMsg}>{errorMsg[carrier.id]}</div>
														)}
													</div>
												) : (
													<button className={styles.whatsappBtn} onClick={() => handleShowWhatsApp(carrier)}>
														<WaIcon />
														Send WhatsApp
													</button>
												)}

												{/* ── Allocate / Unallocate cell ──────── */}
												{isAllocated ? (
													// [5] Allocated row — show badge + unallocate
													<div className={styles.allocatedGroup}>
														<span className={styles.allocatedBadge}>✓ Allocated</span>
														<button className={styles.unallocateBtn} onClick={handleUnallocate}>
															Unallocate
														</button>
													</div>
												) : isGreyedOut ? (
													// [5] Other rows locked or declined — no allocate
													<button className={styles.allocateBtnLocked} disabled>Allocate</button>
												) : (
													<button className={styles.allocateBtn} onClick={() => handleAllocate(carrier.id)}>
														Allocate
													</button>
												)}
											</div>
										</td>
									</tr>
								);
							})}
						</tbody>
					</table>

					<div className={styles.searchCarrier}>
						<div className={styles.searchCarrierLabel}>Search a carrier</div>
						<div className={styles.searchCarrierBox}>
							<input className={styles.searchCarrierInput} placeholder='Search' />
							<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/></svg>
						</div>
					</div>
				</div>
			</div>

			{/* ── Footer ───────────────────────────────────────── */}
			<div className={styles.footer}>
				<button className={styles.cancelBtn}>Cancel Shipment</button>
				<button className={styles.marketplaceBtn} disabled>Send to Marketplace</button>
			</div>
		</div>
	);
};
