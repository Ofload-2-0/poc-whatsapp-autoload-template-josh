import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DUMMY_LOADS } from '../../Data/eos';
import styles from './LoadListPage.module.scss';

const DGIcon = () => (
	<svg width='16' height='16' viewBox='0 0 24 24' fill='none'>
		<path d='M12 2L22 20H2L12 2Z' fill='#E8521A' opacity='0.15' stroke='#E8521A' strokeWidth='1.5'/>
		<text x='12' y='17' textAnchor='middle' fontSize='10' fontWeight='700' fill='#E8521A'>!</text>
	</svg>
);

const StatusBadge = ({ status }: { status: string }) => {
	const isUnallocated = status === 'Unallocated';
	return (
		<span className={`${styles.badge} ${isUnallocated ? styles.badgeUnallocated : styles.badgeAllocated}`}>
			<svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
				{isUnallocated
					? <><circle cx='12' cy='8' r='4'/><path d='M4 20c0-4 3.6-7 8-7s8 3 8 7'/></>
					: <polyline points='20 6 9 17 4 12'/>
				}
			</svg>
			{status}
		</span>
	);
};

const TempBadge = ({ temp }: { temp: string }) => (
	<span className={styles.tempBadge}>
		<svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='#b45309' strokeWidth='2'>
			<circle cx='12' cy='12' r='4'/>
			<line x1='12' y1='2' x2='12' y2='4'/><line x1='12' y1='20' x2='12' y2='22'/>
			<line x1='4.22' y1='4.22' x2='5.64' y2='5.64'/><line x1='18.36' y1='18.36' x2='19.78' y2='19.78'/>
			<line x1='2' y1='12' x2='4' y2='12'/><line x1='20' y1='12' x2='22' y2='12'/>
		</svg>
		{temp}
	</span>
);

export const LoadListPage = () => {
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = useState<'full' | 'partial'>('full');
	const [contextMenu, setContextMenu] = useState<string | null>(null);

	return (
		<div className={styles.page} onClick={() => setContextMenu(null)}>

			{/* ── Page header ──────────────────────────────────── */}
			<div className={styles.pageHeader}>
				<h1 className={styles.title}>Your Shipments</h1>
				<button className={styles.newBtn}>
					<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.5'>
						<line x1='12' y1='5' x2='12' y2='19'/><line x1='5' y1='12' x2='19' y2='12'/>
					</svg>
					New Shipment
				</button>
			</div>

			{/* ── Tabs ──────────────────────────────────────────── */}
			<div className={styles.tabs}>
				<button
					className={`${styles.tab} ${activeTab === 'full' ? styles.tabActive : ''}`}
					onClick={() => setActiveTab('full')}
				>
					Full Bookings
				</button>
				<button
					className={`${styles.tab} ${activeTab === 'partial' ? styles.tabActive : ''}`}
					onClick={() => setActiveTab('partial')}
				>
					Partial Bookings
					<span className={styles.tabBadge}>4</span>
				</button>
			</div>

			{/* ── Table card ──────────────────────────────────── */}
			<div className={styles.card}>
				<div className={styles.toolbar}>
					<button className={styles.filterDropdown}>
						<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<line x1='8' y1='6' x2='21' y2='6'/><line x1='8' y1='12' x2='21' y2='12'/><line x1='8' y1='18' x2='21' y2='18'/>
							<line x1='3' y1='6' x2='3.01' y2='6'/><line x1='3' y1='12' x2='3.01' y2='12'/><line x1='3' y1='18' x2='3.01' y2='18'/>
						</svg>
						All Bookings
						<svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<polyline points='6 9 12 15 18 9'/>
						</svg>
					</button>
					<div className={styles.toolbarRight}>
						<div className={styles.searchWrap}>
							<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
								<circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/>
							</svg>
							<input className={styles.searchInput} placeholder='Search order number' />
						</div>
						<button className={styles.iconBtn} title='Display settings'>
							<svg width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
								<line x1='4' y1='6' x2='20' y2='6'/><line x1='8' y1='12' x2='16' y2='12'/><line x1='11' y1='18' x2='13' y2='18'/>
							</svg>
						</button>
						<button className={styles.iconBtn} title='Filter'>
							<svg width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
								<polygon points='22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3'/>
							</svg>
						</button>
						<button className={styles.iconBtn} title='More'>
							<svg width='15' height='15' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
								<circle cx='12' cy='5' r='1'/><circle cx='12' cy='12' r='1'/><circle cx='12' cy='19' r='1'/>
							</svg>
						</button>
					</div>
				</div>

				<table className={styles.table}>
					<thead>
						<tr>
							<th className={styles.thDg} />
							<th className={styles.th}>Reference #</th>
							<th className={styles.th}>Order #</th>
							<th className={styles.th}>Mode</th>
							<th className={styles.th}>Cargo</th>
							<th className={styles.th}>Notes</th>
							<th className={styles.th}>Status</th>
							<th className={styles.th}>Pick-up Time</th>
							<th className={styles.th}>Pick-up Location</th>
							<th className={styles.thActions} />
						</tr>
					</thead>
					<tbody>
						{DUMMY_LOADS.map(load => (
							<tr
								key={load.id}
								className={styles.row}
								onClick={() => navigate(`/load/${load.id}`)}
							>
								<td className={styles.tdDg}>
									{load.dg && <DGIcon />}
								</td>
								<td className={styles.td}>
									<span className={styles.refLink}>{load.reference}</span>
								</td>
								<td className={styles.td}>{load.orderNumber}</td>
								<td className={styles.td}>{load.mode}</td>
								<td className={styles.td}>
									<TempBadge temp={load.temperature} />
								</td>
								<td className={styles.td}>
									<button className={styles.notesBtn} onClick={e => e.stopPropagation()}>
										<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
											<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/>
											<polyline points='14 2 14 8 20 8'/>
										</svg>
									</button>
								</td>
								<td className={styles.td}>
									<StatusBadge status='Unallocated' />
								</td>
								<td className={styles.td}>
									<div className={styles.pickupTime}>{load.pickupTime}</div>
								</td>
								<td className={styles.td}>
									<div className={styles.pickupLocation}>{load.firstStop.name}</div>
									<div className={styles.pickupAddress}>{load.firstStop.suburb} · {load.firstStop.state} {load.firstStop.postcode}</div>
								</td>
								<td className={styles.tdActions} onClick={e => e.stopPropagation()}>
									<div className={styles.rowActions}>
										<button
											className={styles.moreBtn}
											onClick={e => { e.stopPropagation(); setContextMenu(contextMenu === load.id ? null : load.id); }}
										>
											<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
												<circle cx='12' cy='5' r='1'/><circle cx='12' cy='12' r='1'/><circle cx='12' cy='19' r='1'/>
											</svg>
										</button>
										{contextMenu === load.id && (
											<div className={styles.contextMenu}>
												<button className={styles.contextItem} onClick={() => navigate(`/load/${load.id}`)}>
													<svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
														<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/>
														<path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>
													</svg>
													Allocate
												</button>
												<button className={styles.contextItem}>etc</button>
												<button className={styles.contextItem}>etc</button>
											</div>
										)}
									</div>
								</td>
							</tr>
						))}
					</tbody>
				</table>

				<div className={styles.footer}>
					<div className={styles.footerLeft}>
						Items per page
						<select className={styles.perPage}>
							<option>50</option>
							<option>25</option>
						</select>
					</div>
					<div className={styles.footerRight}>
						<span className={styles.pageCount}>1–{DUMMY_LOADS.length} of {DUMMY_LOADS.length}</span>
						<button className={styles.pageBtn} disabled>
							<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><polyline points='15 18 9 12 15 6'/></svg>
						</button>
						<button className={styles.pageBtn} disabled>
							<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'><polyline points='9 18 15 12 9 6'/></svg>
						</button>
					</div>
				</div>
			</div>
		</div>
	);
};
