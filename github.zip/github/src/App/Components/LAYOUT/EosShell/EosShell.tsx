import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './EosShell.module.scss';

interface IProps {
	children: React.ReactNode;
}

const TOP_NAV = ['Inbox', 'Shipper', 'Carrier', 'Fulfilment', 'Transport', 'Finance', 'Configuration'];

const NAV_ITEMS = [
	{
		label: 'Dashboard',
		to: '/dashboard',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<rect x='3' y='3' width='7' height='7' rx='1'/><rect x='14' y='3' width='7' height='7' rx='1'/>
				<rect x='3' y='14' width='7' height='7' rx='1'/><rect x='14' y='14' width='7' height='7' rx='1'/>
			</svg>
		),
	},
	{
		label: 'Today',
		to: '/today',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>
			</svg>
		),
	},
	{
		label: 'Shipments',
		to: '/',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<rect x='2' y='3' width='20' height='14' rx='2'/><line x1='8' y1='21' x2='16' y2='21'/><line x1='12' y1='17' x2='12' y2='21'/>
			</svg>
		),
		exact: true,
	},
	{
		label: 'Book a Shipment',
		to: '/book',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='16'/><line x1='8' y1='12' x2='16' y2='12'/>
			</svg>
		),
	},
	{
		label: 'Rate Card',
		to: '/rate-card',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<rect x='2' y='5' width='20' height='14' rx='2'/><line x1='2' y1='10' x2='22' y2='10'/>
			</svg>
		),
	},
	{
		label: 'Quotes',
		to: '/quotes',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/>
			</svg>
		),
	},
	{
		label: 'Invoices',
		to: '/invoices',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/>
				<line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/><polyline points='10 9 9 9 8 9'/>
			</svg>
		),
	},
	{
		label: 'Analytics',
		to: '/analytics',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<polyline points='22 12 18 12 15 21 9 3 6 12 2 12'/>
			</svg>
		),
	},
	{
		label: 'Company Details',
		to: '/company',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>
			</svg>
		),
	},
	{
		label: 'Settings',
		to: '/settings',
		icon: (
			<svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
				<circle cx='12' cy='12' r='3'/>
				<path d='M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z'/>
			</svg>
		),
	},
];

export const EosShell = ({ children }: IProps) => {
	const [collapsed, setCollapsed] = useState(false);

	return (
		<div className={`${styles.shell} ${collapsed ? styles.shellCollapsed : ''}`}>
			{/* ── Sidebar ───────────────────────────────────────── */}
			<aside className={styles.sidebar}>
				<div className={styles.sidebarTop}>
					<div className={styles.logo}>
						<span className={styles.logoOf}>OF</span>
						<span className={styles.logoLoad}>LOAD</span>
					</div>
					<button className={styles.collapseBtn} onClick={() => setCollapsed(c => !c)} title='Toggle sidebar'>
						<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							{collapsed
								? <polyline points='9 18 15 12 9 6'/>
								: <polyline points='15 18 9 12 15 6'/>
							}
						</svg>
					</button>
				</div>

				{!collapsed && (
					<div className={styles.roleSelector}>
						<span>Shipper</span>
						<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<polyline points='6 9 12 15 18 9'/>
						</svg>
					</div>
				)}

				<nav className={styles.sideNav}>
					{NAV_ITEMS.map(item => (
						<NavLink
							key={item.label}
							to={item.to}
							end={item.exact}
							className={({ isActive }) =>
								`${styles.navItem} ${isActive ? styles.navItemActive : ''}`
							}
						>
							<span className={styles.navIcon}>{item.icon}</span>
							{!collapsed && <span className={styles.navLabel}>{item.label}</span>}
						</NavLink>
					))}
				</nav>
			</aside>

			{/* ── Main ─────────────────────────────────────────── */}
			<div className={styles.main}>
				{/* Top nav bar */}
				<header className={styles.topNav}>
					<nav className={styles.topNavItems}>
						{TOP_NAV.map(item => (
							<button
								key={item}
								className={`${styles.topNavItem} ${item === 'Shipper' ? styles.topNavItemActive : ''}`}
							>
								{item}
							</button>
						))}
					</nav>
					<div className={styles.userMenu}>
						Username
						<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<polyline points='6 9 12 15 18 9'/>
						</svg>
					</div>
				</header>

				{/* Page content */}
				<main className={styles.content}>
					{children}
				</main>
			</div>
		</div>
	);
};
