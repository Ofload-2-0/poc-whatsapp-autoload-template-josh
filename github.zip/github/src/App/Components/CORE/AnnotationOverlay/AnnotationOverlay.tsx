import { useState, useRef, useEffect } from 'react';
import styles from './AnnotationOverlay.module.scss';

interface IPin {
	id: number;
	x: number; // percentage
	y: number; // percentage
	note: string;
	resolved: boolean;
}

let pinCounter = 1;

export const AnnotationOverlay = () => {
	const [active, setActive] = useState(false);
	const [pins, setPins] = useState<IPin[]>([]);
	const [openPin, setOpenPin] = useState<number | null>(null);
	const [draft, setDraft] = useState('');
	const [showSummary, setShowSummary] = useState(false);
	const overlayRef = useRef<HTMLDivElement>(null);

	// Place a pin on click
	const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
		if ((e.target as HTMLElement).closest(`.${styles.pin}`) ||
			(e.target as HTMLElement).closest(`.${styles.popup}`)) return;

		const rect = overlayRef.current!.getBoundingClientRect();
		const x = ((e.clientX - rect.left) / rect.width) * 100;
		const y = ((e.clientY - rect.top) / rect.height) * 100;
		const id = pinCounter++;

		setPins(prev => [...prev, { id, x, y, note: '', resolved: false }]);
		setOpenPin(id);
		setDraft('');
	};

	const handleSaveNote = (id: number) => {
		setPins(prev => prev.map(p => p.id === id ? { ...p, note: draft } : p));
		setOpenPin(null);
		setDraft('');
	};

	const handleDeletePin = (id: number) => {
		setPins(prev => prev.filter(p => p.id !== id));
		if (openPin === id) setOpenPin(null);
	};

	const handleResolve = (id: number) => {
		setPins(prev => prev.map(p => p.id === id ? { ...p, resolved: !p.resolved } : p));
	};

	const unresolvedPins = pins.filter(p => !p.resolved);
	const [sending, setSending] = useState(false);
	const [sent, setSent] = useState(false);

	const copySummary = () => {
		const text = unresolvedPins
			.map(p => `[${p.id}] ${p.note || '(no note)'}`)
			.join('\n');
		navigator.clipboard.writeText(text);
	};

	const sendToClaude = async () => {
		setSending(true);
		try {
			await fetch('/api/annotations', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					page: window.location.pathname,
					pins: unresolvedPins,
				}),
			});
			setSent(true);
			setTimeout(() => setSent(false), 3000);
		} finally {
			setSending(false);
		}
	};

	// Close popup on Escape
	useEffect(() => {
		const handler = (e: KeyboardEvent) => {
			if (e.key === 'Escape') setOpenPin(null);
		};
		window.addEventListener('keydown', handler);
		return () => window.removeEventListener('keydown', handler);
	}, []);

	return (
		<>
			{/* ── Toggle button ────────────────────────────────── */}
			<button
				className={`${styles.toggle} ${active ? styles.toggleActive : ''}`}
				onClick={() => { setActive(a => !a); setOpenPin(null); }}
				title={active ? 'Exit annotation mode' : 'Enter annotation mode'}
			>
				{active ? (
					<>
						<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>
						</svg>
						Exit Annotation
					</>
				) : (
					<>
						<svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2'>
							<path d='M12 20h9'/><path d='M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z'/>
						</svg>
						Annotate
					</>
				)}
			</button>

			{/* ── Pin count badge ───────────────────────────────── */}
			{pins.length > 0 && (
				<button
					className={styles.summaryToggle}
					onClick={() => setShowSummary(s => !s)}
				>
					📋 {unresolvedPins.length} note{unresolvedPins.length !== 1 ? 's' : ''}
				</button>
			)}

			{/* ── Summary panel ────────────────────────────────── */}
			{showSummary && (
				<div className={styles.summaryPanel}>
					<div className={styles.summaryHeader}>
						<strong>Annotation Notes</strong>
						<button className={styles.closeBtn} onClick={() => setShowSummary(false)}>✕</button>
					</div>
					{pins.length === 0 ? (
						<p className={styles.emptyMsg}>No annotations yet.</p>
					) : (
						<ul className={styles.pinList}>
							{pins.map(p => (
								<li key={p.id} className={`${styles.pinListItem} ${p.resolved ? styles.pinListResolved : ''}`}>
									<span className={styles.pinNum}>{p.id}</span>
									<span className={styles.pinNote}>{p.note || <em>No note</em>}</span>
									<div className={styles.pinActions}>
										<button onClick={() => handleResolve(p.id)} title={p.resolved ? 'Unresolve' : 'Mark resolved'}>
											{p.resolved ? '↩' : '✓'}
										</button>
										<button onClick={() => handleDeletePin(p.id)} title='Delete'>✕</button>
									</div>
								</li>
							))}
						</ul>
					)}
					{unresolvedPins.length > 0 && (
						<div className={styles.summaryFooter}>
							<button className={styles.copyBtn} onClick={copySummary}>
								Copy notes
							</button>
							<button
								className={`${styles.sendClaudeBtn} ${sent ? styles.sendClaudeBtnSent : ''}`}
								onClick={sendToClaude}
								disabled={sending || sent}
							>
								{sent ? '✓ Sent!' : sending ? 'Sending…' : '🤖 Send to Claude'}
							</button>
						</div>
					)}
				</div>
			)}

			{/* ── Overlay ───────────────────────────────────────── */}
			{active && (
				<div
					ref={overlayRef}
					className={styles.overlay}
					onClick={handleOverlayClick}
				>
					<div className={styles.overlayHint}>Click anywhere to drop a pin</div>

					{pins.map(p => (
						<div
							key={p.id}
							className={`${styles.pin} ${p.resolved ? styles.pinResolved : ''}`}
							style={{ left: `${p.x}%`, top: `${p.y}%` }}
							onClick={e => { e.stopPropagation(); setOpenPin(p.id); setDraft(p.note); }}
						>
							{p.id}

							{openPin === p.id && (
								<div
									className={styles.popup}
									onClick={e => e.stopPropagation()}
									style={{ left: p.x > 75 ? 'auto' : '28px', right: p.x > 75 ? '28px' : 'auto', top: p.y > 70 ? 'auto' : '0', bottom: p.y > 70 ? '0' : 'auto' }}
								>
									<textarea
										className={styles.textarea}
										placeholder='Describe the change you want here…'
										value={draft}
										onChange={e => setDraft(e.target.value)}
										autoFocus
										rows={3}
									/>
									<div className={styles.popupActions}>
										<button className={styles.saveBtn} onClick={() => handleSaveNote(p.id)}>Save</button>
										<button className={styles.deleteBtn} onClick={() => handleDeletePin(p.id)}>Delete pin</button>
									</div>
								</div>
							)}
						</div>
					))}
				</div>
			)}
		</>
	);
};
