export type TTemperature = 'Ambient' | 'Chilled' | 'Frozen';
export type TMode = 'Road' | 'Rail';
export type TDG = boolean;

export interface IStop {
	name: string;
	address: string;
	suburb: string;
	state: string;
	postcode: string;
	date: string;
}

export interface ILoad {
	id: string;
	reference: string;
	orderNumber: string;
	shipperName: string;
	costCentre: string;
	cargo: string;
	cargoType: string;
	totalWeight: string;
	pallets: number;
	temperature: TTemperature;
	mode: TMode;
	dg: TDG;
	truckType: string;
	loadRestraints: string;
	palletHandling: string;
	pickupTime: string;
	firstStop: IStop;
	lastStop: IStop;
	transportPrice: number;
	fuelLevy: number;
	warrantyFee: number;
	assignedTo?: string;
}

export interface ICarrier {
	id: string;
	name: string;
	contactName: string;
	contactPhone: string;
	rateCardCost: string;
	rating: number | null;
	hasApp: boolean;
	hasWhatsApp: boolean;
	similarShipments: number;
	totalShipments: number;
}

export const DUMMY_LOADS: ILoad[] = [
	{
		id: 'load-aushz0cz4sj',
		reference: 'AUSHZ0CZ4SJ',
		orderNumber: '6003748205 | 1062288542',
		shipperName: 'Kimberly-Clark Australia Pty. Limited',
		costCentre: 'Kimberly-Clark Austr',
		cargo: 'LTL | 2 Pallets | 107kg',
		cargoType: 'Less Than',
		totalWeight: '107kg',
		pallets: 2,
		temperature: 'Ambient',
		mode: 'Road',
		dg: false,
		truckType: 'Single Tautliner',
		loadRestraints: '-',
		palletHandling: '-',
		pickupTime: '08 Jan 2024\n00:02 - 00:02',
		firstStop: {
			name: 'Toll - Erskine Park',
			address: '35-44 Sarah Andrews Cl',
			suburb: 'Erskine Park',
			state: 'NSW',
			postcode: '2759',
			date: 'Monday, 08 Jan 2024',
		},
		lastStop: {
			name: 'COSTCO WHOLESALE',
			address: 'North Lakes',
			suburb: 'North Lakes',
			state: 'QLD',
			postcode: '4509',
			date: 'Tuesday, 09 Jan 2024',
		},
		transportPrice: 178.00,
		fuelLevy: 1.78,
		warrantyFee: 0.00,
	},
	{
		id: 'load-aushz2xbine',
		reference: 'AUSHZ2XBINE',
		orderNumber: '6003748206 | 1',
		shipperName: 'Kimberly-Clark Australia Pty. Limited',
		costCentre: 'Kimberly-Clark Austr',
		cargo: 'LTL | 1 Pallet | 54kg',
		cargoType: 'Less Than',
		totalWeight: '54kg',
		pallets: 1,
		temperature: 'Ambient',
		mode: 'Road',
		dg: false,
		truckType: 'Single Tautliner',
		loadRestraints: '-',
		palletHandling: '-',
		pickupTime: '08 Jan 2024\n00:02 - 00:02',
		firstStop: {
			name: 'Toll - Erskine Park',
			address: '35-44 Sarah Andrews Cl',
			suburb: 'Erskine Park',
			state: 'NSW',
			postcode: '2759',
			date: 'Monday, 08 Jan 2024',
		},
		lastStop: {
			name: 'Woolworths DC Heathwood',
			address: 'Heathwood',
			suburb: 'Heathwood',
			state: 'QLD',
			postcode: '4110',
			date: 'Wednesday, 10 Jan 2024',
		},
		transportPrice: 142.00,
		fuelLevy: 1.42,
		warrantyFee: 0.00,
	},
	{
		id: 'load-aushz6w5fvr',
		reference: 'AUSHZ6W5FVR',
		orderNumber: '6003747928 | 4',
		shipperName: 'Kimberly-Clark Australia Pty. Limited',
		costCentre: 'Kimberly-Clark Austr',
		cargo: 'LTL | 30 Pallets | 3,200kg',
		cargoType: 'Less Than',
		totalWeight: '3,200kg',
		pallets: 30,
		temperature: 'Ambient',
		mode: 'Road',
		dg: false,
		truckType: 'B-Double High Cube Tautliner',
		loadRestraints: 'Tension belts',
		palletHandling: 'Pallet jack required',
		pickupTime: '08 Jan 2024\n00:02 - 00:02',
		firstStop: {
			name: 'Toll - Erskine Park',
			address: '35-44 Sarah Andrews Cl',
			suburb: 'Erskine Park',
			state: 'NSW',
			postcode: '2759',
			date: 'Monday, 08 Jan 2024',
		},
		lastStop: {
			name: 'Coles DC - Smeaton Grange',
			address: 'Smeaton Grange',
			suburb: 'Smeaton Grange',
			state: 'NSW',
			postcode: '2567',
			date: 'Tuesday, 09 Jan 2024',
		},
		transportPrice: 740.34,
		fuelLevy: 7.40,
		warrantyFee: 0.00,
	},
	{
		id: 'load-aushzhy4tgv',
		reference: 'AUSHZHY4TGV',
		orderNumber: '6003748153',
		shipperName: 'Kimberly-Clark Australia Pty. Limited',
		costCentre: 'Kimberly-Clark Austr',
		cargo: 'LTL | 1 Pallet | 88kg',
		cargoType: 'Less Than',
		totalWeight: '88kg',
		pallets: 1,
		temperature: 'Ambient',
		mode: 'Road',
		dg: false,
		truckType: 'Single Tautliner',
		loadRestraints: '-',
		palletHandling: '-',
		pickupTime: '08 Jan 2024\n05:00 - 05:00',
		firstStop: {
			name: 'Toll - Erskine Park',
			address: '35-44 Sarah Andrews Cl',
			suburb: 'Erskine Park',
			state: 'NSW',
			postcode: '2759',
			date: 'Monday, 08 Jan 2024',
		},
		lastStop: {
			name: 'IGA Distribution Centre',
			address: 'Crestmead',
			suburb: 'Crestmead',
			state: 'QLD',
			postcode: '4132',
			date: 'Wednesday, 10 Jan 2024',
		},
		transportPrice: 195.00,
		fuelLevy: 1.95,
		warrantyFee: 0.00,
	},
	{
		id: 'load-aushzvm986i',
		reference: 'AUSHZVM986I',
		orderNumber: '6003748159 | B',
		shipperName: 'Kimberly-Clark Australia Pty. Limited',
		costCentre: 'Kimberly-Clark Austr',
		cargo: 'LTL | 11 Pallets | 940kg',
		cargoType: 'Less Than',
		totalWeight: '940kg',
		pallets: 11,
		temperature: 'Ambient',
		mode: 'Road',
		dg: false,
		truckType: 'Semi-Trailer Tautliner',
		loadRestraints: 'Tension belts',
		palletHandling: '-',
		pickupTime: '08 Jan 2024\n00:02 - 00:02',
		firstStop: {
			name: 'Toll - Erskine Park',
			address: '35-44 Sarah Andrews Cl',
			suburb: 'Erskine Park',
			state: 'NSW',
			postcode: '2759',
			date: 'Monday, 08 Jan 2024',
		},
		lastStop: {
			name: 'Coles DC - Smeaton Grange',
			address: 'Smeaton Grange',
			suburb: 'Smeaton Grange',
			state: 'NSW',
			postcode: '2567',
			date: 'Tuesday, 09 Jan 2024',
		},
		transportPrice: 420.00,
		fuelLevy: 4.20,
		warrantyFee: 0.00,
	},
];

export const DUMMY_CARRIERS: ICarrier[] = [
	{
		id: 'carrier-001',
		name: 'Tony Innaimo Transport Pty Ltd',
		contactName: 'Darren Linehaul Mgr SYD',
		contactPhone: '+61400261234',
		rateCardCost: 'No Rate Available',
		rating: 73,
		hasApp: false,
		hasWhatsApp: true,
		similarShipments: 1,
		totalShipments: 5,
	},
	{
		id: 'carrier-002',
		name: 'Don Watson Pty Ltd',
		contactName: 'Jake Sgubin',
		contactPhone: '+61353676655',
		rateCardCost: 'No Rate Available',
		rating: 40,
		hasApp: false,
		hasWhatsApp: false,
		similarShipments: 0,
		totalShipments: 2,
	},
	{
		id: 'carrier-003',
		name: 'Rainbow and sons heavy haulage',
		contactName: 'Dylan Rainbow',
		contactPhone: '+610467645014',
		rateCardCost: 'No Rate Available',
		rating: 19,
		hasApp: false,
		hasWhatsApp: false,
		similarShipments: 1,
		totalShipments: 1,
	},
	{
		id: 'carrier-004',
		name: 'Punjab Motor Transport Pty Ltd',
		contactName: 'Sukh Pal Singh Maidh',
		contactPhone: '+61451757890',
		rateCardCost: 'No Rate Available',
		rating: 17,
		hasApp: false,
		hasWhatsApp: true,
		similarShipments: 1,
		totalShipments: 1,
	},
	{
		id: 'carrier-005',
		name: 'Skyway Logistics',
		contactName: 'Kuldeep Kailey',
		contactPhone: '+61406260033',
		rateCardCost: 'No Rate Available',
		rating: 5,
		hasApp: false,
		hasWhatsApp: false,
		similarShipments: 2,
		totalShipments: 2,
	},
	{
		id: 'carrier-006',
		name: 'Brisbane Transport Pty LTD',
		contactName: 'Gary Badesha',
		contactPhone: '+61452145401',
		rateCardCost: 'No Rate Available',
		rating: null,
		hasApp: false,
		hasWhatsApp: true,
		similarShipments: 2,
		totalShipments: 4,
	},
	{
		id: 'carrier-007',
		name: 'Blacks Transport QLD',
		contactName: 'Daniel Black',
		contactPhone: '+61732778792',
		rateCardCost: 'No Rate Available',
		rating: null,
		hasApp: false,
		hasWhatsApp: true,
		similarShipments: 1,
		totalShipments: 2,
	},
];
