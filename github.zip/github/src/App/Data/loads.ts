export interface ILoadRecord {
	id: string;
	label: string;
	variables: [string, string, string, string, string, string, string, string, string, string];
}

export const DUMMY_LOADS: ILoadRecord[] = [
	{
		id: 'load-001',
		label: 'LOD-001 • Eagle Farm → Arndell Park',
		variables: [
			'Eagle Farm 4009 QLD',
			'Fri 14 Feb 2026 • 09:00–17:00',
			'Arndell Park 2148 NSW',
			'Mon 17 Feb 2026 • 09:00–17:00',
			'Ambient • 24 pallets • 10,000 kg',
			'B-Double High Cube Tautliner',
			'Pallet jack required',
			'Tension belts | Anti slip mat',
			'No',
			'$740.34 (Excl. GST)',
		],
	},
	{
		id: 'load-002',
		label: 'LOD-002 • Port Melbourne → Yatala',
		variables: [
			'Port Melbourne 3207 VIC',
			'Mon 17 Feb 2026 • 06:00–10:00',
			'Yatala 4207 QLD',
			'Wed 19 Feb 2026 • 08:00–14:00',
			'Chilled • 18 pallets • 7,200 kg',
			'Semi-Trailer Refrigerated',
			'Tail lift required',
			'Straps x6 | Blankets',
			'No',
			'$1,240.00 (Excl. GST)',
		],
	},
	{
		id: 'load-003',
		label: 'LOD-003 • Wetherill Park → Bibra Lake',
		variables: [
			'Wetherill Park 2164 NSW',
			'Tue 18 Feb 2026 • 07:00–12:00',
			'Bibra Lake 6163 WA',
			'Fri 21 Feb 2026 • 09:00–15:00',
			'Dangerous Goods • 8 pallets • 3,400 kg',
			'Rigid Truck (12t)',
			'No special handling',
			'Chains x4 | DG placards required',
			'Yes — Class 3 Flammable Liquid',
			'$980.00 (Excl. GST)',
		],
	},
];
