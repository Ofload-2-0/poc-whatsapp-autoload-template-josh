import { Routes, Route } from 'react-router-dom';
import { EosShell } from './App/Components/LAYOUT/EosShell/EosShell';
import { LoadListPage } from './App/Pages/LoadList/LoadListPage';
import { LoadDetailPage } from './App/Pages/LoadDetail/LoadDetailPage';
import { AllocateCarrierPage } from './App/Pages/AllocateCarrier/AllocateCarrierPage';
import { AnnotationOverlay } from './App/Components/CORE/AnnotationOverlay/AnnotationOverlay';

const App = () => {
	return (
		<>
			<EosShell>
				<Routes>
					<Route path='/' element={<LoadListPage />} />
					<Route path='/load/:id' element={<LoadDetailPage />} />
					<Route path='/load/:id/allocate' element={<AllocateCarrierPage />} />
				</Routes>
			</EosShell>
			<AnnotationOverlay />
		</>
	);
};

export default App;
